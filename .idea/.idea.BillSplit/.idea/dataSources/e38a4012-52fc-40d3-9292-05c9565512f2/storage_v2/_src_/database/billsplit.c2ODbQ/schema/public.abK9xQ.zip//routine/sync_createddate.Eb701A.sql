create function sync_createddate() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW."CreatedDate" := NOW();

    RETURN NEW;
END;
$$;

alter function sync_createddate() owner to postgres;

