create function sync_updateddate() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW."UpdatedDate" := NOW();

    RETURN NEW;
END;
$$;

alter function sync_updateddate() owner to postgres;

